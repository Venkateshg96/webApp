package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.model.Cart;
import com.example.demo.model.Product;
import com.example.demo.repository.cartRepository;
import com.example.demo.repository.productRepository;

import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

@Controller
public class cartController {
	
	@Autowired
	cartRepository cartRepo;
	@Autowired
	productRepository productRepo;
	
	@RequestMapping("dashboard/{id}")
	public String saveToCart(@PathVariable(value="id") int id,HttpSession session,RedirectAttributes redirectAttributes)
	{
		Cart ct = new Cart();
		System.out.println(id);
		String email =(String)session.getAttribute("email");
		
		Product p = productRepo.findById(id).orElse(null);
		
		Cart c=cartRepo.findByEmailAndPrice(email,p.getPrice());
		
		System.out.println(c);
		if(c==null)
		{
			ct.setDescription(p.getDescription());
			ct.setEmail(email);
			ct.setImageUrl(p.getImageUrl());
			ct.setPrice(p.getPrice());
			ct.setProductname(p.getProductname());
			System.out.println(ct);
			cartRepo.save(ct);
			//m.addAttribute("message", "Product successfully added to your cart");
			
			redirectAttributes.addFlashAttribute("message", "Product successfully added to your cart");
			
			return "redirect:/dashboard";
		}
		else {
			redirectAttributes.addFlashAttribute("message", "Product Aleady added to your cart");
			//m.addAttribute("message", "Product Aleady added to your cart");
			return "redirect:/dashboard";
		}
		
	}
	
	
	@RequestMapping("/cart")
	public String cart(HttpSession session,Model model) {
		String email =(String)session.getAttribute("email");
		
		List<Cart> cartList= cartRepo.findByEmail(email);
		model.addAttribute("cartList", cartList);
		model.addAttribute("email", email);
		
		System.out.println(cartList);
		return "cart";
	}
	
	
	@GetMapping("/delete/{id}")
	public String deleteById(@PathVariable int id)
	{
		
		cartRepo.deleteById(id);
		return "redirect:/cart";
	}
	
	
	@GetMapping("/deleteAll/{email}")
	@Transactional
	public String deleteById(@PathVariable String email)
	{
		
		cartRepo.removeUsersByEmail(email);
		return "redirect:/cart";
	}
	
	
	
	
	
	

}
