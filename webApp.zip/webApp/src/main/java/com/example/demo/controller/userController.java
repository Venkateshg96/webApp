package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.repository.productRepository;
import com.example.demo.repository.userRepository;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;


@Controller
public class userController {
	
	@Autowired
	userRepository userRepo;
	@Autowired
	productRepository productRepo;
	
	@GetMapping("/home")
	public String reg(HttpSession session) {
		
		if (session.getAttribute("email") == null){
	        // User is not logged in, redirect to the login page
	        return "home";
	    }
		return "dashboard";
	}
	
	@RequestMapping("/register")
	public String register(@Valid @ModelAttribute User u,Model m) {
		
		
		User exits = userRepo.findByEmail(u.getEmail());
		if(exits!=null)
		{
			m.addAttribute("Failed","Email Already Registered");
			return "home";
			
		}else {
			userRepo.save(u);
			m.addAttribute("success","Registration successfull");
			return "login";
		}
		
	}
	
	@RequestMapping("/login")
	public String view(HttpSession session)
	{
		if (session.getAttribute("email") == null ) {
	        // User is not logged in, redirect to the login page
	        return "login";
	    }
		return "dashboard";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
	    // Invalidate the user's session
	    session.invalidate();

	    // Redirect to the login page
	    return "redirect:/login";
	}
	
	
	@RequestMapping("/dashboard")
	public String dashboard(Model m)
	{
		List<Product> allProducts = productRepo.findAll();
		m.addAttribute("products", allProducts);
		System.out.println(allProducts);
		return "dashboard";
	}
	
	@RequestMapping("/authenticate")
	public String login(@ModelAttribute User u,Model m,HttpSession session)
	{
		User exits = userRepo.findByEmailAndPassword(u.getEmail(),u.getPassword());
		if(exits!=null)
		{
			session.setAttribute("email", u.getEmail());
			
			return "redirect:/dashboard";
		}
		return "login";
	}
	


}
