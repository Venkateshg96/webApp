package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.Id;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name= "UserTable")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int Id;
	
	@NotEmpty(message = "firstname cannot be Empty")
	@NotNull(message = "firstname cannot be null")
	@Column
	private String firstname;
	
	@NotEmpty(message = "LastName cannot be Empty")
	@NotNull(message = "LastName Feild cannot be null")
	@Column
	private String lastname;
	
	
	@Email(message="Plase Enter the valid Email")
	@Column
	private String email;
	
	@NotEmpty(message = "password cannot be Empty")
	@NotNull(message = "password cannot be null")
	@Column
	private String password;
	

}