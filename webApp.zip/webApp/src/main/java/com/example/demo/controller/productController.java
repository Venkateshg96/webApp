package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Product;
import com.example.demo.repository.productRepository;

@RestController
public class productController {
	@Autowired
	productRepository productRepo;
	
	@PostMapping("product")
	public Product saveProduct(@RequestBody Product p) {
		return productRepo.save(p);
	}
	
	
	
	
	

}
