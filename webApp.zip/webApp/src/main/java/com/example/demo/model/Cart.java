package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name="cart")
public class Cart {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int Id;
	
	@Email(message="Plase Enter the valid Email")
	@Column
	private String email;
	
	
	@Column
	@NotEmpty(message = "productname cannot be Empty")
	@NotNull(message = "productname cannot be null")
	private String productname;
	
	@Column(columnDefinition = "TEXT")
	@NotEmpty(message = "description cannot be Empty")
	@NotNull(message = "description cannot be null")
	private String description;
	
	@Column
	@NotEmpty(message = "imageUrl cannot be Empty")
	@NotNull(message = "imageUrl cannot be null")
	private String imageUrl;
	
	
	
	@Column
	private Long price;

	

}
