package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Cart;

@Repository
public interface cartRepository extends JpaRepository<Cart, Integer>{

	Cart findByemail(String string);

	Cart findByEmailAndPrice(String email, Long price);

	List<Cart> findByEmail(String email);


	void removeUsersByEmail(String email);

	

	
	

	

}
